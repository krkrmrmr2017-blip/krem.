<?php
// Default XAMPP settings. Change these if your MySQL settings differ.
$host = '127.0.0.1';
$port = '3306';
$dbname = 'kareem_portfolio';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $error) {
    error_log($error->getMessage());
    http_response_code(503);
    exit('Database unavailable. Start MySQL, import database.sql, and check db.php.');
}
