-- Import this file once using phpMyAdmin > Import.
-- Skills, projects, and messages are preserved; profile identity is updated to the requested Hail revision.
CREATE DATABASE IF NOT EXISTS kareem_portfolio CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE kareem_portfolio;

CREATE TABLE IF NOT EXISTS profile (
    id INT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    title VARCHAR(150) NOT NULL,
    intro TEXT NOT NULL,
    about_text TEXT NOT NULL,
    university VARCHAR(150) NOT NULL,
    location VARCHAR(100) NOT NULL,
    focus VARCHAR(150) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    technologies VARCHAR(255) NOT NULL,
    symbol VARCHAR(20) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(254) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO profile VALUES
(1, 'Kareem Al-Ramali', 'Web Development Student',
'I build practical projects and keep developing my skills in web development.',
'I am a student at the University of Ha''il interested in web development. This sample portfolio presents fictional practice projects and example skills in frontend and backend development.',
'University of Ha''il', 'Ha''il', 'Web Development');

INSERT IGNORE INTO skills (id, name, category, description) VALUES
(1, 'HTML', 'Frontend', 'Sample skill: organizing web content with semantic elements.'),
(2, 'CSS', 'Frontend', 'Sample skill: styling pages and creating responsive layouts.'),
(3, 'JavaScript', 'Frontend', 'Sample skill: handling events and updating page elements.'),
(4, 'PHP', 'Backend', 'Sample skill: processing forms and displaying dynamic content.'),
(5, 'MySQL', 'Database', 'Sample skill: creating tables and retrieving records with SQL.'),
(6, 'Git Basics', 'Tools', 'Sample skill: tracking code changes in a local repository.');

INSERT IGNORE INTO projects (id, title, category, description, technologies, symbol) VALUES
(1, 'Task Planner', 'web', 'Fictional practice project: a task organizer concept with priorities and completion tracking.', 'HTML / CSS / JavaScript', 'TP'),
(2, 'Book Catalog', 'web', 'Fictional practice project: a searchable book catalog concept with categories and reading lists.', 'PHP / MySQL / CSS', 'BC'),
(3, 'Smart Recycling Bin', 'innovation', 'Fictional concept: a recycling bin that indicates its fill level and encourages waste sorting.', 'Sensors / Product Concept', 'SR');

-- Apply this revision even if another version was imported previously.
UPDATE profile SET
    full_name = 'Kareem Al-Ramali',
    university = 'University of Ha''il',
    location = 'Ha''il',
    about_text = 'I am a student at the University of Ha''il interested in web development. This sample portfolio presents fictional practice projects and example skills in frontend and backend development.'
WHERE id = 1;
