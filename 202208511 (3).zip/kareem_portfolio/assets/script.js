const themeButton = document.getElementById('theme-toggle');
function setTheme(light) {
    document.body.classList.toggle('light', light);
    themeButton.textContent = light ? 'Dark mode' : 'Light mode';
    themeButton.setAttribute('aria-pressed', String(light));
}
let savedTheme = 'dark';
try { savedTheme = localStorage.getItem('portfolio-theme') || 'dark'; } catch (error) {}
setTheme(savedTheme === 'light');
themeButton.addEventListener('click', () => {
    const light = !document.body.classList.contains('light');
    setTheme(light);
    try { localStorage.setItem('portfolio-theme', light ? 'light' : 'dark'); } catch (error) {}
});

const filterButtons = document.querySelectorAll('.filter');
const projects = document.querySelectorAll('.project');
const count = document.getElementById('project-count');
function filterProjects(category) {
    let visible = 0;
    projects.forEach(project => {
        project.hidden = category !== 'all' && project.dataset.category !== category;
        if (!project.hidden) visible++;
    });
    filterButtons.forEach(button => {
        const active = button.dataset.filter === category;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', String(active));
    });
    count.textContent = visible + (visible === 1 ? ' project shown' : ' projects shown');
}
filterButtons.forEach(button => button.addEventListener('click', () => filterProjects(button.dataset.filter)));
filterProjects('all');
