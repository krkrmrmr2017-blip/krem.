<?php
session_start();
require 'db.php';
function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
$profile = $pdo->query('SELECT * FROM profile WHERE id = 1')->fetch();
if (!$profile) {
    http_response_code(503);
    exit('Profile missing. Import database.sql first.');
}
$skills = $pdo->query('SELECT * FROM skills ORDER BY id')->fetchAll();
$projects = $pdo->query('SELECT * FROM projects ORDER BY id')->fetchAll();
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
unset($_SESSION['errors'], $_SESSION['old']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= e($profile['full_name']) ?> - Student portfolio">
    <title><?= e($profile['full_name']) ?> | Portfolio</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js" defer></script>
</head>
<body>
<a class="skip" href="#home">Skip to content</a>
<header>
    <nav class="container" aria-label="Main navigation">
        <a class="brand" href="#home">KR<span>.</span></a>
        <div class="nav-links">
            <a href="#home">Home</a><a href="#about">About</a>
            <a href="#skills">Skills</a><a href="#projects">Projects</a><a href="#contact">Contact</a>
        </div>
        <button type="button" id="theme-toggle" class="theme-button" aria-pressed="false">Light mode</button>
    </nav>
</header>
<main>
    <section id="home" class="hero container">
        <div>
            <p class="eyebrow">PERSONAL PORTFOLIO</p>
            <h1>Hello, I'm<br><span><?= e($profile['full_name']) ?></span></h1>
            <p class="role"><?= e($profile['title']) ?></p>
            <p class="intro"><?= e($profile['intro']) ?></p>
            <div class="actions"><a class="button" href="#projects">View my projects</a><a class="button secondary" href="#contact">Contact me</a></div>
        </div>
        <div class="code-card" aria-label="Profile overview">
            <div class="code-top"><span></span><span></span><span></span><small>developer.php</small></div>
            <p class="code-comment">// Learning. Building. Improving.</p>
            <p><b>$developer</b> = [</p>
            <p class="indent">'name' =&gt; '<?= e($profile['full_name']) ?>',</p>
            <p class="indent">'focus' =&gt; 'Web Development',</p>
            <p class="indent">'location' =&gt; '<?= e($profile['location']) ?>'</p>
            <p>];</p>
            <div class="code-footer">PHP &nbsp; / &nbsp; MySQL &nbsp; / &nbsp; JavaScript</div>
        </div>
    </section>
    <section id="about" class="container section">
        <p class="eyebrow">01 / INTRODUCTION</p><h2>About me</h2>
        <div class="about-grid"><p><?= e($profile['about_text']) ?></p>
            <dl class="details"><div><dt>University</dt><dd><?= e($profile['university']) ?></dd></div><div><dt>Location</dt><dd><?= e($profile['location']) ?></dd></div><div><dt>Focus</dt><dd><?= e($profile['focus']) ?></dd></div></dl>
        </div>
    </section>
    <section id="skills" class="container section">
        <p class="eyebrow">02 / TOOLKIT</p><h2>My skills</h2>
        <div class="grid skills-grid">
        <?php foreach ($skills as $skill): ?>
            <article class="card"><p class="tag"><?= e($skill['category']) ?></p><h3><?= e($skill['name']) ?></h3><p><?= e($skill['description']) ?></p></article>
        <?php endforeach; ?>
        </div>
    </section>
    <section id="projects" class="container section">
        <p class="eyebrow">03 / SELECTED WORK</p><h2>My projects</h2>
        <div class="filters" aria-label="Filter projects">
            <button type="button" class="filter active" data-filter="all" aria-pressed="true">All projects</button>
            <button type="button" class="filter" data-filter="web" aria-pressed="false">Web</button>
            <button type="button" class="filter" data-filter="innovation" aria-pressed="false">Innovation</button>
        </div>
        <div class="grid project-grid">
        <?php foreach ($projects as $index => $project): ?>
            <article class="card project" data-category="<?= e($project['category']) ?>">
                <div class="project-art art-<?= ($index % 3) + 1 ?>" aria-hidden="true"><span><?= e($project['symbol']) ?></span></div>
                <div class="project-body"><p class="tag"><?= e($project['category']) ?></p><h3><?= e($project['title']) ?></h3><p><?= e($project['description']) ?></p><p class="tech"><?= e($project['technologies']) ?></p></div>
            </article>
        <?php endforeach; ?>
        </div>
        <p id="project-count" class="muted" aria-live="polite"></p>
    </section>
    <section id="contact" class="container section contact-grid">
        <div><p class="eyebrow">04 / GET IN TOUCH</p><h2>Let's connect.</h2><p>Have a question or a project idea? Send me a message.</p><p class="muted">Messages are saved in the local MySQL database.</p></div>
        <form action="contact.php" method="post">
            <?php if ($errors): ?><div class="error" role="alert"><?php foreach ($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?></div><?php endif; ?>
            <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
            <label for="name">Name</label><input id="name" name="name" required minlength="2" maxlength="100" autocomplete="name" value="<?= e($old['name'] ?? '') ?>">
            <label for="email">Email</label><input type="email" id="email" name="email" required maxlength="254" autocomplete="email" value="<?= e($old['email'] ?? '') ?>">
            <label for="message">Message</label><textarea id="message" name="message" required minlength="10" maxlength="2000" rows="5"><?= e($old['message'] ?? '') ?></textarea>
            <button class="button" type="submit">Send message</button>
        </form>
    </section>
</main>
<footer class="container">&copy; <?= date('Y') ?> <?= e($profile['full_name']) ?> <span>Built with PHP &amp; MySQL</span></footer>
</body>
</html>
