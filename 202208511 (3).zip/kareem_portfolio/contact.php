<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php#contact');
    exit;
}
require 'db.php';
// Check the session token before accepting a message.
$token = $_POST['csrf'] ?? '';
if (!is_string($token) || !isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
    http_response_code(403);
    exit('Invalid form session. Return to index.php and try again.');
}
function field($key) {
    return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : '';
}
$name = field('name');
$email = field('email');
$message = field('message');
function textLength($value) {
    return preg_match_all('/./us', $value);
}
$errors = [];
if (textLength($name) < 2 || textLength($name) > 100) $errors[] = 'Name must be between 2 and 100 characters.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254) $errors[] = 'Enter a valid email address.';
if (textLength($message) < 10 || textLength($message) > 2000) $errors[] = 'Message must be between 10 and 2000 characters.';
if ($errors) {
    $_SESSION['errors'] = $errors;
    $_SESSION['old'] = ['name' => $name, 'email' => $email, 'message' => $message];
    header('Location: index.php#contact', true, 303);
    exit;
}
try {
    // Placeholders keep user input separate from SQL commands.
    $statement = $pdo->prepare('INSERT INTO messages (name, email, message) VALUES (?, ?, ?)');
    $statement->execute([$name, $email, $message]);
} catch (PDOException $error) {
    error_log($error->getMessage());
    $_SESSION['errors'] = ['Could not save your message. Please try again.'];
    $_SESSION['old'] = ['name' => $name, 'email' => $email, 'message' => $message];
    header('Location: index.php#contact', true, 303);
    exit;
}
$_SESSION['csrf'] = bin2hex(random_bytes(32));
header('Location: success.html', true, 303);
exit;
